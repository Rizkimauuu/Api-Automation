const { expect } = require('chai');
const supertest = require("supertest");

describe('POST Add Contact', () => {

	it('Succes Post Add Contact', async () => {
		const response = await supertest('https://thinking-tester-contact-list.herokuapp.com')
		.post('/contacts')
		.set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjI4OTQ3ZDY3YzgwNjAwMTNlM2VkZmMiLCJpYXQiOjE3MTQwMTIyNTV9.m-YDEpY7tlcYExZiLpeaMrU2LhDE7my-gw6pz-L26mI')
		.send({
			"firstName": "John",
			"lastName": "Doe",
			"birthdate": "1970-01-01",
			"email": "jdoe@fake.com",
			"phone": "8005555555",
			"street1": "1 Main St.",
			"street2": "Apartment A",
			"city": "Anytown",
			"stateProvince": "KS",
			"postalCode": "12345",
			"country": "USA"
		})
		.set('content-Type', 'applicatio/json')
		console.log(response)
		//expect(response.status).equal(200)
		expect(response.body)

	})
})