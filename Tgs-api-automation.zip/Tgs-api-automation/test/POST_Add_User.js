const { expect } = require('chai');
const supertest = require("supertest");

describe('POST Add User', () => {

	it('Succes Post Add User', async () => {
		const response = await supertest('https://thinking-tester-contact-list.herokuapp.com')
		.post('/users')
		.set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjI4OTQ3ZDY3YzgwNjAwMTNlM2VkZmMiLCJpYXQiOjE3MTQwMTIyNTV9.m-YDEpY7tlcYExZiLpeaMrU2LhDE7my-gw6pz-L26mI')
		.send({
			"firstName": "Test",
			"lastName": "User",
			"email": "test@fake.com",
			"password": "myPassword"
		})
		.set('content-Type', 'applicatio/json')
		console.log(response)
		//expect(response.status).equal(200)
		expect(response.body)

	})
})