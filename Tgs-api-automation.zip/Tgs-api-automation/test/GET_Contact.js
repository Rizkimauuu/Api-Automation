const { expect } = require('chai');
const supertest = require('supertest');

describe('Get Contact', () => {

	it('Succes Get Contact', async () => {
		const response = await supertest('https://thinking-tester-contact-list.herokuapp.com')
		.get('/contacts/')
		.set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjI4OTQ3ZDY3YzgwNjAwMTNlM2VkZmMiLCJpYXQiOjE3MTQwMTIyNTV9.m-YDEpY7tlcYExZiLpeaMrU2LhDE7my-gw6pz-L26mI')
		console.log(response.status)
		console.log(response.body)
		expect(response.status).equal(200)
		expect(response.body)

	})
})