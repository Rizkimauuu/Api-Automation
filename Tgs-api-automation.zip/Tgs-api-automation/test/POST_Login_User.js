const { expect } = require('chai');
const supertest = require("supertest");

describe('POST Login User', () => {

	it('Succes Post Login User', async () => {
		const response = await supertest('https://thinking-tester-contact-list.herokuapp.com')
		.post('/users/login')
		.send({
			"email": "test2@fake.com",
			"password": "myNewPassword"
		})
		.set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjI4OTQ3ZDY3YzgwNjAwMTNlM2VkZmMiLCJpYXQiOjE3MTQwMTIyNTV9.m-YDEpY7tlcYExZiLpeaMrU2LhDE7my-gw6pz-L26mI')
		console.log(response.body)
		expect(response.status).equal(200)
		expect(response.body)

	})
})