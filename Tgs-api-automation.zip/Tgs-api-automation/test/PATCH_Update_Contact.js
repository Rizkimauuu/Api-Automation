const { expect } = require('chai');
const supertest = require("supertest");

describe('PATCH Update Contact', () => {

	it('Succes Patch Update Contact', async () => {
		const response = await supertest('https://thinking-tester-contact-list.herokuapp.com')
		.post('/contacts')
		.set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NjI4OTQ3ZDY3YzgwNjAwMTNlM2VkZmMiLCJpYXQiOjE3MTQwMTIyNTV9.m-YDEpY7tlcYExZiLpeaMrU2LhDE7my-gw6pz-L26mI')
		.send({
			"firstName": "Anna"
		})
		.set('content-Type', 'applicatio/json')
		console.log(response)
		//expect(response.status).equal(200)
		expect(response.body)

	})
})